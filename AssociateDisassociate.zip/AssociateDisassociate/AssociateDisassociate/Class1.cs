﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace AssociateDisassociate
{
    public class Class1 : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            #region
            /*
            string relationshipName = string.Empty;

            tracingService.Trace("Message name " + context.MessageName.ToString());

                if (context.MessageName == "Associate" || context.MessageName == "Disassociate")
                {
                    if (context.InputParameters.Contains("Relationship") && context.InputParameters["Relationship"] is Relationship)
                    {
                        
                        Relationship ntonrelation = context.InputParameters["Relationship"] as Relationship;
                        if (ntonrelation.SchemaName.ToLower() == "new_new_entitybtest_new_entityatest")
                        {
                            try
                            {
                                if (context.MessageName == "Associate")
                                    {
                                        tracingService.Trace("Associate");
                                    }

                                    if (context.MessageName == "Disassociate")
                                    {
                                        tracingService.Trace("Disassociate");
                                    }

                            }
                            catch (FaultException<OrganizationServiceFault> ex)
                            {
                                throw new InvalidPluginExecutionException("An error occurred in the Associate/Disassociate plug-in.", ex);
                            }

                            catch (Exception ex)
                            {
                                tracingService.Trace("Associate/Disassociate: {0}", ex.ToString());
                                throw;
                            }
                        }                      
                    }
                }
            */
            #endregion

            EntityReference targetEntity = null;
            string strRelationshipName = string.Empty;
            EntityReferenceCollection relatedEntities = null;
            EntityReference relatedEntity = null;
            if (context.MessageName == "Associate")
            {
                // Get the "Relationship" Key from context
                if (context.InputParameters.Contains("Relationship"))
                {
                    strRelationshipName = context.InputParameters["Relationship"].ToString();
                }
                // Check the "Relationship Name" with your intended one
                if (strRelationshipName != "new_new_entitybtest_new_entityatest.")
                {
                    return;
                }
                // Get Entity 1 reference from "Target" Key from context
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
                {
                    targetEntity = (EntityReference)context.InputParameters["Target"];
                    
                }
                // Get Entity 2 reference from "RelatedEntities" Key from context
                if (context.InputParameters.Contains("RelatedEntities") && context.InputParameters["RelatedEntities"] is EntityReferenceCollection)
                {
                    relatedEntities = context.InputParameters["RelatedEntities"] as EntityReferenceCollection;
                    relatedEntity = relatedEntities[0];
                    
                    Entity entityBTest1 = new Entity("new_entitybtest");
                    entityBTest1.Id = targetEntity.Id;
                    entityBTest1["new_entitytesta"] = new EntityReference("new_entityatest", relatedEntity.Id);
                    service.Update(entityBTest1);
                }
            }
            if (context.MessageName == "Disassociate")
            {
                // Get the "Relationship" Key from context
                if (context.InputParameters.Contains("Relationship"))
                {
                    strRelationshipName = context.InputParameters["Relationship"].ToString();
                }
                // Check the "Relationship Name" with your intended one
                if (strRelationshipName != "new_new_entitybtest_new_entityatest.")
                {
                    return;
                }
                // Get Entity 1 reference from "Target" Key from context
                if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is EntityReference)
                {
                    targetEntity = (EntityReference)context.InputParameters["Target"];
                }
                // Get Entity 2 reference from "RelatedEntities" Key from context
                if (context.InputParameters.Contains("RelatedEntities") && context.InputParameters["RelatedEntities"] is EntityReferenceCollection)
                {
                    relatedEntities = context.InputParameters["RelatedEntities"] as EntityReferenceCollection;
                    relatedEntity = relatedEntities[0];

                    Entity entityATest = service.Retrieve("new_entitybtest", relatedEntity.Id, new ColumnSet(new string[] { "new_entitytesta" }));

                    Entity entityATest1 = new Entity("new_entitybtest");
                    entityATest1.Id = entityATest.Id;
                    entityATest1["new_entitytesta"] = null;
                    service.Update(entityATest1);
                }
            }
        }
    }
}